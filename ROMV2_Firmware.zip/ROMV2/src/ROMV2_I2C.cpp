#include <ROMV2_I2C.h>

/// ----------------------------
/// D�finition du membre statique
/// ----------------------------
SemaphoreHandle_t ROMV2_I2C::_mutex = nullptr;

/// <summary>
/// Cr�e le mutex (idempotent : ne fait rien s'il existe d�j�).
/// </summary>
void ROMV2_I2C::Init()
{
    if (_mutex == nullptr)
        _mutex = xSemaphoreCreateMutex();
}

/// <summary>
/// Renvoie le handle du mutex.
/// </summary>
SemaphoreHandle_t ROMV2_I2C::Handle()
{
    return _mutex;
}