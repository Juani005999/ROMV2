#pragma once

// Include des librairies
#include <ROMV2_APP_CONFIG.h>

/// <summary>
/// Objet ROMV2_I2C : Verrou partag� du bus I2C (Wire).
/// Prot�ge le bus contre les acc�s concurrents entre la t�che TSL2591 (coeur 0)
/// et les lectures BME280 / MLX90614 / ADXL345 effectu�es dans Loop() (coeur 1),
/// qui s'ex�cutent sur des coeurs diff�rents et peuvent donc viser le bus
/// v�ritablement en parall�le.
/// </summary>
class ROMV2_I2C
{
public:
    /// <summary>
    /// Cr�e le mutex (idempotent).
    /// </summary>
    static void Init();

    /// <summary>
    /// Renvoie le handle du mutex (utilis� par le garde I2CLock).
    /// </summary>
    static SemaphoreHandle_t Handle();

private:
    // Membre statique : un seul bus I2C => un seul verrou pour tout le projet
    static SemaphoreHandle_t _mutex;
};

/// <summary>
/// Garde RAII : prend le verrou I2C � la construction, le rend automatiquement
/// � la destruction (fin de scope). �vite tout xSemaphoreGive() oubli�, y compris
/// sur un return anticip�.
///
/// Usage :
///   {
///       I2CLock lock(pdMS_TO_TICKS(15));
///       if (!lock.ok()) return;        // bus occup� -> on saute la lecture
///       ... transaction(s) I2C ...
///   }                                  // verrou rendu ici, automatiquement
/// </summary>
class I2CLock
{
public:
    /// <summary>
    /// Tente de prendre le verrou avec un timeout. ok() indique le succ�s.
    /// </summary>
    /// <param name="timeout">D�lai d'attente max (ex. pdMS_TO_TICKS(15))</param>
    explicit I2CLock(TickType_t timeout)
    {
        // D�fensif : si Init() n'a pas encore tourn�, on consid�re le verrou non pris
        SemaphoreHandle_t handle = ROMV2_I2C::Handle();
        _taken = (handle != nullptr) && (xSemaphoreTake(handle, timeout) == pdTRUE);
    }

    /// <summary>
    /// Lib�re le verrou s'il avait �t� pris.
    /// </summary>
    ~I2CLock()
    {
        if (_taken)
            xSemaphoreGive(ROMV2_I2C::Handle());
    }

    /// <summary>
    /// True si le verrou a bien �t� pris dans le d�lai imparti.
    /// </summary>
    bool ok() const { return _taken; }

    // Un verrou ne se copie pas
    I2CLock(const I2CLock&) = delete;
    I2CLock& operator=(const I2CLock&) = delete;

private:
    bool _taken;
};
